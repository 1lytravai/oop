import cv2

def put_text(image):
    font = cv2.FONT_HERSHEY_SIMPLEX 
    org = (50, 50) 
    fontScale = 1
    color = (255, 0, 0) 
    thickness = 2
    image = cv2.putText(image, '521H0435', org, font,  fontScale, color, thickness, cv2.LINE_AA)
    return image

img = cv2.imread('sudoku-original.jpg') 
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
img_blur = cv2.GaussianBlur(img_gray, (3,3), 0) 

# Sobel Edge Detection
#  X axis
sobel_x = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=1, dy=0, ksize=5) 
# Y axis
sobel_y = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=0, dy=1, ksize=5)
# X and Y
sobel_xy = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=1, dy=1, ksize=5) 

# Canny Edge Detection
edges = cv2.Canny(image=img_blur, threshold1=100, threshold2=200) 

cv2.imwrite("image_01_01.png", put_text(sobel_x))
cv2.imwrite("image_01_02.png", put_text(sobel_y))
cv2.imwrite("image_01_03.png", put_text(sobel_xy))
cv2.imwrite("image_01_04.png", put_text(edges))

